<?php

//add_action( 'wp_enqueue_scripts', 'casino_styles_scripts' );

//function casino_scripts() {

//    wp_enqueue_style( 'casino-fonts', get_template_directory_uri() . '/css/fonts.css' );
//    wp_enqueue_style( 'casino-media', get_template_directory_uri() . '/css/media.css' );
//    wp_enqueue_style( 'casino-style', get_template_directory_uri() . '/css/style.css' );
//    wp_enqueue_style( 'casino-owl-carousel', get_template_directory_uri() . '/css/owl.carousel.css' );
//    wp_enqueue_style( 'casino-owl-theme', get_template_directory_uri() . '/css/owl.theme.css' );
//    wp_enqueue_style( 'casino-owl-transitions', get_template_directory_uri() . '/css/owl.transitions.css' );
//    wp_enqueue_style( 'casino-bootstrap-theme', get_template_directory_uri() . '/css/bootstrap-theme.min.css' );
//    wp_enqueue_style( 'casino-bootstrap', get_template_directory_uri() . '/css/bootstrap.min.css' );

//    wp_enqueue_script( 'casino-owl-js', get_template_directory_uri() . '/js/owl.carousel.min.js' );
//    wp_enqueue_script( 'casino-bootstrap-js', get_template_directory_uri() . '/js/bootstrap.min.js' );
//    wp_enqueue_script( 'casino-npm-js', get_template_directory_uri() . '/js/npm.js' );
//    wp_enqueue_script( 'casino-common-js', get_template_directory_uri() . '/js/common.js' );
//
//    wp_deregister_script('casino-jquery');
//    wp_register_script('casino-jquery', 'http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js', false);
//    wp_enqueue_script('casino-jquery');

//}
